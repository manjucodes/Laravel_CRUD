## Simple Laravel CRUD Application

A simple laravel task management application using Laravel 8.25.




# Installation 


````
1. Composer install
````sh
composer install
````
2. Copy `.env.example` file and create `.env` file
3. Add Database Credential like yours in `.env`
```php
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=your_db_name
DB_USERNAME=root
DB_PASSWORD=
```
4. Go to the project - 
```sh
cd Laravel-Simple-CRUD-App
```
5. Run Project inside that directory - 
````sh
php artisan serve
````
6. Open in Browser 
````sh
http://localhost:8000
````



